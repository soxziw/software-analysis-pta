#!/bin/bash
java -jar tai-e-all-0.5.1-SNAPSHOT.jar -a pku-pta-trivial -cp testcase -m $1